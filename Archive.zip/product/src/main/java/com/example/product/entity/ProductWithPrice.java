package com.example.product.entity;

import lombok.Data;

@Data
public class ProductWithPrice {
    private String productId;
    private String productName;
    private String brand;
    private String description;
    private String imgSrc;
    private String productPrice;
}
