package com.example.merchantMicroService.dto;

import lombok.Data;

@Data
public class MerchantProductsDTO {
    private String productId;
    private String productName;
    private String brand;
    private String description;
    private String imgSrc;
    private Integer productStock;
    private Integer price;
}
