package com.example.emailservice.controller;

import com.example.emailservice.entity.Email;
import com.example.emailservice.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/mail")
@RestController
public class EmailController
{
    @Autowired
    EmailService emailService;

    @PostMapping("/sendMail")
    public String sendMail(@RequestBody Email details)
    {
        String result= emailService.sendSimpleMail(details);
        return  result;
    }
}
