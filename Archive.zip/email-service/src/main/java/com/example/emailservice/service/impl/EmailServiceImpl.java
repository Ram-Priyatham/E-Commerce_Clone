package com.example.emailservice.service.impl;

import com.example.emailservice.entity.Email;
import com.example.emailservice.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;


@Service
public class EmailServiceImpl implements EmailService {

 @Autowired
    private JavaMailSender javaMailSender;

 @Value("${spring.mail.username}") private String sender;

 @Override
 public String sendSimpleMail(Email details){
     try{
         SimpleMailMessage simpleMailMessage=new SimpleMailMessage();
         simpleMailMessage.setFrom(sender);
         simpleMailMessage.setTo(details.getRecipientMail());
         simpleMailMessage.setText(details.getMsgBody());
         simpleMailMessage.setSubject(details.getSubject());

         javaMailSender.send(simpleMailMessage);
         return "Mail sent successfully";
     }
     catch(Exception e){
         return "Error while sending message";
     }
 }
}
