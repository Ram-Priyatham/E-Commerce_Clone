package com.example.emailservice.service;

import com.example.emailservice.entity.Email;

public interface EmailService {
    String sendSimpleMail(Email details);

}
