package com.example.cart.feign;

import com.example.cart.dto.UserDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(url = "localhost:8087/users", value = "user")
public interface FeignUserInterface {
    @GetMapping("/getUserById/{emailId}")
    public UserDTO getUserById(@PathVariable("emailId") String emailId);
}
